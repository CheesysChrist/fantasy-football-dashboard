# nestjs-utils

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build nestjs-utils` to build the library.

## Running unit tests

Run `nx test nestjs-utils` to execute the unit tests via [Vitest](https://vitest.dev/).
