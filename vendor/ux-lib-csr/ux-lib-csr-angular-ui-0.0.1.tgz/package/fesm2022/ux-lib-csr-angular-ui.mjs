import * as i0 from '@angular/core';
import { HostBinding, Input, Directive, ChangeDetectionStrategy, Component, EventEmitter, Output, makeEnvironmentProviders } from '@angular/core';
import * as i2 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i1$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DecimalPipe } from '@angular/common';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';

class UxButtonDirective {
    uxVariant = 'primary';
    uxSize = 'md';
    uxLoading = false;
    get hostClasses() {
        return `ux-button ux-button--${this.uxVariant} ux-button--${this.uxSize}${this.uxLoading ? ' ux-button--loading' : ''}`;
    }
    get ariaBusy() {
        return this.uxLoading ? 'true' : null;
    }
    get disabled() {
        return this.uxLoading ? '' : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.14", type: UxButtonDirective, isStandalone: true, selector: "button[uxButton], a[uxButton]", inputs: { uxVariant: "uxVariant", uxSize: "uxSize", uxLoading: "uxLoading" }, host: { properties: { "class": "this.hostClasses", "attr.aria-busy": "this.ariaBusy", "attr.disabled": "this.disabled" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[uxButton], a[uxButton]',
                    standalone: true,
                }]
        }], propDecorators: { uxVariant: [{
                type: Input
            }], uxSize: [{
                type: Input
            }], uxLoading: [{
                type: Input
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], ariaBusy: [{
                type: HostBinding,
                args: ['attr.aria-busy']
            }], disabled: [{
                type: HostBinding,
                args: ['attr.disabled']
            }] } });

class UxAlertComponent {
    title = 'Notice';
    variant = 'info';
    get role() {
        return this.variant === 'danger' || this.variant === 'warning' ? 'alert' : 'status';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.14", type: UxAlertComponent, isStandalone: true, selector: "ux-alert", inputs: { title: "title", variant: "variant" }, ngImport: i0, template: "<section class=\"ux-alert ux-alert--{{ variant }}\" [attr.role]=\"role\">\n  <strong class=\"ux-alert__title\">{{ title }}</strong>\n  <p class=\"ux-alert__message\"><ng-content /></p>\n</section>\n", styles: [".ux-alert{border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-md, 10px);padding:var(--ux-space-md, 16px);background:var(--ux-color-surface, #ffffff)}.ux-alert__title{display:block;margin-bottom:var(--ux-space-xs, 4px)}.ux-alert__message{margin:0;color:var(--ux-color-muted-text, #667085)}.ux-alert--success{border-color:var(--ux-color-success-border, rgba(46, 125, 91, .35))}.ux-alert--warning{border-color:var(--ux-color-warning-border, rgba(181, 71, 8, .35))}.ux-alert--danger{border-color:var(--ux-color-danger-border, rgba(180, 35, 24, .35))}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-alert', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"ux-alert ux-alert--{{ variant }}\" [attr.role]=\"role\">\n  <strong class=\"ux-alert__title\">{{ title }}</strong>\n  <p class=\"ux-alert__message\"><ng-content /></p>\n</section>\n", styles: [".ux-alert{border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-md, 10px);padding:var(--ux-space-md, 16px);background:var(--ux-color-surface, #ffffff)}.ux-alert__title{display:block;margin-bottom:var(--ux-space-xs, 4px)}.ux-alert__message{margin:0;color:var(--ux-color-muted-text, #667085)}.ux-alert--success{border-color:var(--ux-color-success-border, rgba(46, 125, 91, .35))}.ux-alert--warning{border-color:var(--ux-color-warning-border, rgba(181, 71, 8, .35))}.ux-alert--danger{border-color:var(--ux-color-danger-border, rgba(180, 35, 24, .35))}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], variant: [{
                type: Input
            }] } });

class UxDashboardCardComponent {
    title = '';
    eyebrow = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxDashboardCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxDashboardCardComponent, isStandalone: true, selector: "ux-dashboard-card", inputs: { title: "title", eyebrow: "eyebrow" }, ngImport: i0, template: "<article class=\"ux-dashboard-card\">\n  <header class=\"ux-dashboard-card__header\">\n    @if (eyebrow) {\n      <span class=\"ux-dashboard-card__eyebrow\">{{ eyebrow }}</span>\n    }\n    <h2>{{ title }}</h2>\n  </header>\n  <ng-content />\n</article>\n", styles: [".ux-dashboard-card{background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);padding:var(--ux-space-lg, 24px);box-shadow:var(--ux-shadow-card, 0 12px 30px rgba(16, 24, 40, .08));color:var(--ux-color-text, #182230)}.ux-dashboard-card__header{display:flex;flex-direction:column;gap:var(--ux-space-xs, 4px);margin-bottom:var(--ux-space-md, 16px)}.ux-dashboard-card__eyebrow{color:var(--ux-color-muted-text, #667085);font-size:.75rem;text-transform:uppercase;letter-spacing:.08em}.ux-dashboard-card h2{margin:0;font-size:1.1rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxDashboardCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-dashboard-card', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<article class=\"ux-dashboard-card\">\n  <header class=\"ux-dashboard-card__header\">\n    @if (eyebrow) {\n      <span class=\"ux-dashboard-card__eyebrow\">{{ eyebrow }}</span>\n    }\n    <h2>{{ title }}</h2>\n  </header>\n  <ng-content />\n</article>\n", styles: [".ux-dashboard-card{background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);padding:var(--ux-space-lg, 24px);box-shadow:var(--ux-shadow-card, 0 12px 30px rgba(16, 24, 40, .08));color:var(--ux-color-text, #182230)}.ux-dashboard-card__header{display:flex;flex-direction:column;gap:var(--ux-space-xs, 4px);margin-bottom:var(--ux-space-md, 16px)}.ux-dashboard-card__eyebrow{color:var(--ux-color-muted-text, #667085);font-size:.75rem;text-transform:uppercase;letter-spacing:.08em}.ux-dashboard-card h2{margin:0;font-size:1.1rem}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], eyebrow: [{
                type: Input
            }] } });

class UxDataPanelComponent {
    title = '';
    subtitle = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxDataPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxDataPanelComponent, isStandalone: true, selector: "ux-data-panel", inputs: { title: "title", subtitle: "subtitle" }, ngImport: i0, template: "<mat-card class=\"ux-data-panel\">\n  <header class=\"ux-data-panel__header\">\n    <div class=\"ux-data-panel__heading\">\n      @if (title) {\n        <h2 class=\"ux-data-panel__title\">{{ title }}</h2>\n      }\n\n      @if (subtitle) {\n        <p class=\"ux-data-panel__subtitle\">{{ subtitle }}</p>\n      }\n    </div>\n\n    <div class=\"ux-data-panel__actions\">\n      <ng-content select=\"[uxDataPanelActions]\" />\n    </div>\n  </header>\n\n  <mat-card-content class=\"ux-data-panel__content\">\n    <ng-content />\n  </mat-card-content>\n</mat-card>\n", styles: [".ux-data-panel{background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);box-shadow:var(--ux-shadow-card, 0 12px 30px rgba(16, 24, 40, .08));color:var(--ux-color-text, #182230);display:block;padding:var(--ux-space-lg, 24px)}.ux-data-panel__header{align-items:flex-start;display:flex;gap:var(--ux-space-md, 16px);justify-content:space-between;margin-bottom:var(--ux-space-md, 16px)}.ux-data-panel__heading{display:grid;gap:var(--ux-space-xs, 4px);min-width:0}.ux-data-panel__title{margin:0;font-size:1.1rem;font-weight:700}.ux-data-panel__subtitle{margin:0;color:var(--ux-color-muted-text, #667085)}.ux-data-panel__actions{align-items:center;display:inline-flex;flex-wrap:wrap;gap:var(--ux-space-sm, 8px);justify-content:flex-end}.ux-data-panel__content{display:grid;gap:var(--ux-space-md, 16px);padding:0}\n"], dependencies: [{ kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i2.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i2.MatCardContent, selector: "mat-card-content" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxDataPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-data-panel', standalone: true, imports: [MatCardModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-card class=\"ux-data-panel\">\n  <header class=\"ux-data-panel__header\">\n    <div class=\"ux-data-panel__heading\">\n      @if (title) {\n        <h2 class=\"ux-data-panel__title\">{{ title }}</h2>\n      }\n\n      @if (subtitle) {\n        <p class=\"ux-data-panel__subtitle\">{{ subtitle }}</p>\n      }\n    </div>\n\n    <div class=\"ux-data-panel__actions\">\n      <ng-content select=\"[uxDataPanelActions]\" />\n    </div>\n  </header>\n\n  <mat-card-content class=\"ux-data-panel__content\">\n    <ng-content />\n  </mat-card-content>\n</mat-card>\n", styles: [".ux-data-panel{background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);box-shadow:var(--ux-shadow-card, 0 12px 30px rgba(16, 24, 40, .08));color:var(--ux-color-text, #182230);display:block;padding:var(--ux-space-lg, 24px)}.ux-data-panel__header{align-items:flex-start;display:flex;gap:var(--ux-space-md, 16px);justify-content:space-between;margin-bottom:var(--ux-space-md, 16px)}.ux-data-panel__heading{display:grid;gap:var(--ux-space-xs, 4px);min-width:0}.ux-data-panel__title{margin:0;font-size:1.1rem;font-weight:700}.ux-data-panel__subtitle{margin:0;color:var(--ux-color-muted-text, #667085)}.ux-data-panel__actions{align-items:center;display:inline-flex;flex-wrap:wrap;gap:var(--ux-space-sm, 8px);justify-content:flex-end}.ux-data-panel__content{display:grid;gap:var(--ux-space-md, 16px);padding:0}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }] } });

class UxEmptyStateComponent {
    title = 'Nothing to show';
    description = '';
    icon = 'inbox';
    variant = 'card';
    primaryActionLabel = '';
    secondaryActionLabel = '';
    primaryAction = new EventEmitter();
    secondaryAction = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxEmptyStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxEmptyStateComponent, isStandalone: true, selector: "ux-empty-state", inputs: { title: "title", description: "description", icon: "icon", variant: "variant", primaryActionLabel: "primaryActionLabel", secondaryActionLabel: "secondaryActionLabel" }, outputs: { primaryAction: "primaryAction", secondaryAction: "secondaryAction" }, ngImport: i0, template: "<mat-card class=\"ux-empty-state ux-empty-state--{{ variant }}\">\n  <mat-card-content class=\"ux-empty-state__content\">\n    <mat-icon class=\"ux-empty-state__icon\" aria-hidden=\"true\">{{ icon }}</mat-icon>\n    <h2 class=\"ux-empty-state__title\">{{ title }}</h2>\n\n    @if (description) {\n      <p class=\"ux-empty-state__description\">{{ description }}</p>\n    }\n\n    @if (primaryActionLabel || secondaryActionLabel) {\n      <div class=\"ux-empty-state__actions\">\n        @if (secondaryActionLabel) {\n          <button mat-button type=\"button\" (click)=\"secondaryAction.emit()\">{{ secondaryActionLabel }}</button>\n        }\n\n        @if (primaryActionLabel) {\n          <button mat-flat-button color=\"primary\" type=\"button\" (click)=\"primaryAction.emit()\">\n            {{ primaryActionLabel }}\n          </button>\n        }\n      </div>\n    }\n  </mat-card-content>\n</mat-card>\n", styles: [".ux-empty-state{background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);color:var(--ux-color-text, #182230)}.ux-empty-state__content{align-items:center;display:flex;flex-direction:column;gap:var(--ux-space-sm, 8px);padding:var(--ux-space-xl, 32px);text-align:center}.ux-empty-state__icon{color:var(--ux-color-muted-text, #667085);font-size:2rem;height:2rem;width:2rem}.ux-empty-state__title{margin:0;font-size:1.125rem;font-weight:700}.ux-empty-state__description{margin:0;max-width:42rem;color:var(--ux-color-muted-text, #667085)}.ux-empty-state__actions{display:inline-flex;flex-wrap:wrap;gap:var(--ux-space-sm, 8px);justify-content:center;margin-top:var(--ux-space-sm, 8px)}.ux-empty-state--page{background:transparent;border:0;box-shadow:none}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i2.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i2.MatCardContent, selector: "mat-card-content" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxEmptyStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-empty-state', standalone: true, imports: [MatButtonModule, MatCardModule, MatIconModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-card class=\"ux-empty-state ux-empty-state--{{ variant }}\">\n  <mat-card-content class=\"ux-empty-state__content\">\n    <mat-icon class=\"ux-empty-state__icon\" aria-hidden=\"true\">{{ icon }}</mat-icon>\n    <h2 class=\"ux-empty-state__title\">{{ title }}</h2>\n\n    @if (description) {\n      <p class=\"ux-empty-state__description\">{{ description }}</p>\n    }\n\n    @if (primaryActionLabel || secondaryActionLabel) {\n      <div class=\"ux-empty-state__actions\">\n        @if (secondaryActionLabel) {\n          <button mat-button type=\"button\" (click)=\"secondaryAction.emit()\">{{ secondaryActionLabel }}</button>\n        }\n\n        @if (primaryActionLabel) {\n          <button mat-flat-button color=\"primary\" type=\"button\" (click)=\"primaryAction.emit()\">\n            {{ primaryActionLabel }}\n          </button>\n        }\n      </div>\n    }\n  </mat-card-content>\n</mat-card>\n", styles: [".ux-empty-state{background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);color:var(--ux-color-text, #182230)}.ux-empty-state__content{align-items:center;display:flex;flex-direction:column;gap:var(--ux-space-sm, 8px);padding:var(--ux-space-xl, 32px);text-align:center}.ux-empty-state__icon{color:var(--ux-color-muted-text, #667085);font-size:2rem;height:2rem;width:2rem}.ux-empty-state__title{margin:0;font-size:1.125rem;font-weight:700}.ux-empty-state__description{margin:0;max-width:42rem;color:var(--ux-color-muted-text, #667085)}.ux-empty-state__actions{display:inline-flex;flex-wrap:wrap;gap:var(--ux-space-sm, 8px);justify-content:center;margin-top:var(--ux-space-sm, 8px)}.ux-empty-state--page{background:transparent;border:0;box-shadow:none}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], description: [{
                type: Input
            }], icon: [{
                type: Input
            }], variant: [{
                type: Input
            }], primaryActionLabel: [{
                type: Input
            }], secondaryActionLabel: [{
                type: Input
            }], primaryAction: [{
                type: Output
            }], secondaryAction: [{
                type: Output
            }] } });

class UxLoadingStateComponent {
    label = 'Loading';
    message = '';
    mode = 'skeleton';
    rows = 3;
    showAvatar = false;
    get skeletonRows() {
        return Array.from({ length: Math.max(1, this.rows) }, (_, index) => index);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxLoadingStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxLoadingStateComponent, isStandalone: true, selector: "ux-loading-state", inputs: { label: "label", message: "message", mode: "mode", rows: "rows", showAvatar: "showAvatar" }, ngImport: i0, template: "<section class=\"ux-loading-state ux-loading-state--{{ mode }}\" aria-busy=\"true\" [attr.aria-label]=\"label\">\n  @if (mode === 'spinner') {\n    <mat-progress-spinner class=\"ux-loading-state__spinner\" diameter=\"40\" mode=\"indeterminate\" />\n    <div class=\"ux-loading-state__copy\">\n      <strong class=\"ux-loading-state__label\">{{ label }}</strong>\n      @if (message) {\n        <p class=\"ux-loading-state__message\">{{ message }}</p>\n      }\n    </div>\n  } @else {\n    <div class=\"ux-loading-state__skeleton\" aria-hidden=\"true\">\n      @if (showAvatar) {\n        <span class=\"ux-loading-state__avatar\"></span>\n      }\n\n      <div class=\"ux-loading-state__lines\">\n        @for (row of skeletonRows; track row) {\n          <span class=\"ux-loading-state__line ux-loading-state__line--{{ row === 0 ? 'title' : 'body' }}\"></span>\n        }\n      </div>\n    </div>\n\n    @if (message) {\n      <p class=\"ux-loading-state__message\">{{ message }}</p>\n    }\n  }\n</section>\n", styles: [".ux-loading-state{align-items:center;color:var(--ux-color-text, #182230);display:flex;gap:var(--ux-space-md, 16px);justify-content:center;min-height:8rem;padding:var(--ux-space-lg, 24px)}.ux-loading-state__spinner{flex:0 0 auto}.ux-loading-state__copy{display:grid;gap:var(--ux-space-xs, 4px)}.ux-loading-state__label{font-size:.9375rem}.ux-loading-state__message{margin:0;color:var(--ux-color-muted-text, #667085)}.ux-loading-state__skeleton{align-items:center;display:flex;gap:var(--ux-space-md, 16px);width:min(100%,32rem)}.ux-loading-state__avatar{background:linear-gradient(90deg,#d9e2ece6,#d9e2ec73,#d9e2ece6);background-size:200% 100%;border-radius:999px;flex:0 0 auto;height:3rem;width:3rem;animation:ux-loading-state-shimmer 1.2s ease-in-out infinite}.ux-loading-state__lines{display:grid;gap:var(--ux-space-sm, 8px);flex:1 1 auto}.ux-loading-state__line{background:linear-gradient(90deg,#d9e2ece6,#d9e2ec73,#d9e2ece6);background-size:200% 100%;border-radius:999px;display:block;height:.875rem;animation:ux-loading-state-shimmer 1.2s ease-in-out infinite}.ux-loading-state__line--title{width:min(60%,16rem)}.ux-loading-state__line--body{width:100%}.ux-loading-state--spinner{flex-direction:column;text-align:center}@keyframes ux-loading-state-shimmer{0%{background-position:200% 0}to{background-position:-200% 0}}\n"], dependencies: [{ kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i1$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxLoadingStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-loading-state', standalone: true, imports: [MatProgressSpinnerModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"ux-loading-state ux-loading-state--{{ mode }}\" aria-busy=\"true\" [attr.aria-label]=\"label\">\n  @if (mode === 'spinner') {\n    <mat-progress-spinner class=\"ux-loading-state__spinner\" diameter=\"40\" mode=\"indeterminate\" />\n    <div class=\"ux-loading-state__copy\">\n      <strong class=\"ux-loading-state__label\">{{ label }}</strong>\n      @if (message) {\n        <p class=\"ux-loading-state__message\">{{ message }}</p>\n      }\n    </div>\n  } @else {\n    <div class=\"ux-loading-state__skeleton\" aria-hidden=\"true\">\n      @if (showAvatar) {\n        <span class=\"ux-loading-state__avatar\"></span>\n      }\n\n      <div class=\"ux-loading-state__lines\">\n        @for (row of skeletonRows; track row) {\n          <span class=\"ux-loading-state__line ux-loading-state__line--{{ row === 0 ? 'title' : 'body' }}\"></span>\n        }\n      </div>\n    </div>\n\n    @if (message) {\n      <p class=\"ux-loading-state__message\">{{ message }}</p>\n    }\n  }\n</section>\n", styles: [".ux-loading-state{align-items:center;color:var(--ux-color-text, #182230);display:flex;gap:var(--ux-space-md, 16px);justify-content:center;min-height:8rem;padding:var(--ux-space-lg, 24px)}.ux-loading-state__spinner{flex:0 0 auto}.ux-loading-state__copy{display:grid;gap:var(--ux-space-xs, 4px)}.ux-loading-state__label{font-size:.9375rem}.ux-loading-state__message{margin:0;color:var(--ux-color-muted-text, #667085)}.ux-loading-state__skeleton{align-items:center;display:flex;gap:var(--ux-space-md, 16px);width:min(100%,32rem)}.ux-loading-state__avatar{background:linear-gradient(90deg,#d9e2ece6,#d9e2ec73,#d9e2ece6);background-size:200% 100%;border-radius:999px;flex:0 0 auto;height:3rem;width:3rem;animation:ux-loading-state-shimmer 1.2s ease-in-out infinite}.ux-loading-state__lines{display:grid;gap:var(--ux-space-sm, 8px);flex:1 1 auto}.ux-loading-state__line{background:linear-gradient(90deg,#d9e2ece6,#d9e2ec73,#d9e2ece6);background-size:200% 100%;border-radius:999px;display:block;height:.875rem;animation:ux-loading-state-shimmer 1.2s ease-in-out infinite}.ux-loading-state__line--title{width:min(60%,16rem)}.ux-loading-state__line--body{width:100%}.ux-loading-state--spinner{flex-direction:column;text-align:center}@keyframes ux-loading-state-shimmer{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], message: [{
                type: Input
            }], mode: [{
                type: Input
            }], rows: [{
                type: Input
            }], showAvatar: [{
                type: Input
            }] } });

class UxPlayerCardComponent {
    player;
    actionLabel = '';
    selectPlayer = new EventEmitter();
    get trend() {
        return this.player?.trend ?? 'neutral';
    }
    get trendLabel() {
        switch (this.trend) {
            case 'add':
                return 'Trending up';
            case 'drop':
                return 'Trending down';
            default:
                return 'Stable';
        }
    }
    get trendIcon() {
        switch (this.trend) {
            case 'add':
                return 'trending_up';
            case 'drop':
                return 'trending_down';
            default:
                return 'remove';
        }
    }
    get meta() {
        return [this.player?.position, this.player?.team].filter(Boolean).join(' · ');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxPlayerCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxPlayerCardComponent, isStandalone: true, selector: "ux-player-card", inputs: { player: "player", actionLabel: "actionLabel" }, outputs: { selectPlayer: "selectPlayer" }, ngImport: i0, template: "<mat-card class=\"ux-player-card ux-player-card--{{ trend }}\" role=\"group\" [attr.aria-label]=\"player.fullName + ', ' + meta\">\n  <mat-card-content class=\"ux-player-card__content\">\n    <div class=\"ux-player-card__identity\">\n      <div>\n        <h3 class=\"ux-player-card__name\">{{ player.fullName }}</h3>\n        <p class=\"ux-player-card__meta\">{{ meta }}</p>\n      </div>\n\n      @if (player.status) {\n        <span class=\"ux-player-card__status\">{{ player.status }}</span>\n      }\n    </div>\n\n    <div class=\"ux-player-card__details\">\n      @if (player.projectedPoints !== null && player.projectedPoints !== undefined) {\n        <div class=\"ux-player-card__projection\" aria-label=\"Projected fantasy points\">\n          <span class=\"ux-player-card__projection-label\">Projected</span>\n          <strong class=\"ux-player-card__projection-value\">{{ player.projectedPoints | number: '1.0-1' }}</strong>\n        </div>\n      }\n\n      <div class=\"ux-player-card__trend\">\n        <mat-icon class=\"ux-player-card__trend-icon\" aria-hidden=\"true\">{{ trendIcon }}</mat-icon>\n        <span>{{ trendLabel }}</span>\n      </div>\n    </div>\n\n    @if (actionLabel) {\n      <button mat-button type=\"button\" (click)=\"selectPlayer.emit(player)\">{{ actionLabel }}</button>\n    }\n  </mat-card-content>\n</mat-card>\n", styles: [".ux-player-card{border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);box-shadow:var(--ux-shadow-sm, 0 1px 2px rgba(16, 24, 40, .06))}.ux-player-card--add{border-left:4px solid var(--ux-color-success, #2e7d5b)}.ux-player-card--drop{border-left:4px solid var(--ux-color-danger, #b42318)}.ux-player-card--neutral{border-left:4px solid var(--ux-color-muted-text, #667085)}.ux-player-card__content{display:grid;gap:var(--ux-space-md, 16px)}.ux-player-card__identity,.ux-player-card__details{align-items:center;display:flex;justify-content:space-between;gap:var(--ux-space-md, 16px)}.ux-player-card__name{color:var(--ux-color-text, #182230);font-size:1rem;font-weight:700;line-height:1.2;margin:0}.ux-player-card__meta,.ux-player-card__projection-label{color:var(--ux-color-muted-text, #667085);font-size:.8125rem;margin:var(--ux-space-xs, 4px) 0 0}.ux-player-card__status{background:var(--ux-color-surface-muted, #f8fafc);border-radius:var(--ux-radius-full, 999px);color:var(--ux-color-text, #182230);font-size:.75rem;font-weight:600;padding:var(--ux-space-xs, 4px) var(--ux-space-sm, 8px);white-space:nowrap}.ux-player-card__projection{display:grid;gap:var(--ux-space-xs, 4px)}.ux-player-card__projection-value{color:var(--ux-color-text, #182230);font-size:1.5rem;line-height:1}.ux-player-card__trend{align-items:center;color:var(--ux-color-muted-text, #667085);display:inline-flex;font-size:.875rem;font-weight:600;gap:var(--ux-space-xs, 4px)}.ux-player-card--add .ux-player-card__trend{color:var(--ux-color-success, #2e7d5b)}.ux-player-card--drop .ux-player-card__trend{color:var(--ux-color-danger, #b42318)}.ux-player-card__trend-icon{font-size:1.125rem;height:1.125rem;width:1.125rem}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i2.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i2.MatCardContent, selector: "mat-card-content" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: DecimalPipe, name: "number" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxPlayerCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-player-card', standalone: true, imports: [DecimalPipe, MatButtonModule, MatCardModule, MatIconModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-card class=\"ux-player-card ux-player-card--{{ trend }}\" role=\"group\" [attr.aria-label]=\"player.fullName + ', ' + meta\">\n  <mat-card-content class=\"ux-player-card__content\">\n    <div class=\"ux-player-card__identity\">\n      <div>\n        <h3 class=\"ux-player-card__name\">{{ player.fullName }}</h3>\n        <p class=\"ux-player-card__meta\">{{ meta }}</p>\n      </div>\n\n      @if (player.status) {\n        <span class=\"ux-player-card__status\">{{ player.status }}</span>\n      }\n    </div>\n\n    <div class=\"ux-player-card__details\">\n      @if (player.projectedPoints !== null && player.projectedPoints !== undefined) {\n        <div class=\"ux-player-card__projection\" aria-label=\"Projected fantasy points\">\n          <span class=\"ux-player-card__projection-label\">Projected</span>\n          <strong class=\"ux-player-card__projection-value\">{{ player.projectedPoints | number: '1.0-1' }}</strong>\n        </div>\n      }\n\n      <div class=\"ux-player-card__trend\">\n        <mat-icon class=\"ux-player-card__trend-icon\" aria-hidden=\"true\">{{ trendIcon }}</mat-icon>\n        <span>{{ trendLabel }}</span>\n      </div>\n    </div>\n\n    @if (actionLabel) {\n      <button mat-button type=\"button\" (click)=\"selectPlayer.emit(player)\">{{ actionLabel }}</button>\n    }\n  </mat-card-content>\n</mat-card>\n", styles: [".ux-player-card{border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);box-shadow:var(--ux-shadow-sm, 0 1px 2px rgba(16, 24, 40, .06))}.ux-player-card--add{border-left:4px solid var(--ux-color-success, #2e7d5b)}.ux-player-card--drop{border-left:4px solid var(--ux-color-danger, #b42318)}.ux-player-card--neutral{border-left:4px solid var(--ux-color-muted-text, #667085)}.ux-player-card__content{display:grid;gap:var(--ux-space-md, 16px)}.ux-player-card__identity,.ux-player-card__details{align-items:center;display:flex;justify-content:space-between;gap:var(--ux-space-md, 16px)}.ux-player-card__name{color:var(--ux-color-text, #182230);font-size:1rem;font-weight:700;line-height:1.2;margin:0}.ux-player-card__meta,.ux-player-card__projection-label{color:var(--ux-color-muted-text, #667085);font-size:.8125rem;margin:var(--ux-space-xs, 4px) 0 0}.ux-player-card__status{background:var(--ux-color-surface-muted, #f8fafc);border-radius:var(--ux-radius-full, 999px);color:var(--ux-color-text, #182230);font-size:.75rem;font-weight:600;padding:var(--ux-space-xs, 4px) var(--ux-space-sm, 8px);white-space:nowrap}.ux-player-card__projection{display:grid;gap:var(--ux-space-xs, 4px)}.ux-player-card__projection-value{color:var(--ux-color-text, #182230);font-size:1.5rem;line-height:1}.ux-player-card__trend{align-items:center;color:var(--ux-color-muted-text, #667085);display:inline-flex;font-size:.875rem;font-weight:600;gap:var(--ux-space-xs, 4px)}.ux-player-card--add .ux-player-card__trend{color:var(--ux-color-success, #2e7d5b)}.ux-player-card--drop .ux-player-card__trend{color:var(--ux-color-danger, #b42318)}.ux-player-card__trend-icon{font-size:1.125rem;height:1.125rem;width:1.125rem}\n"] }]
        }], propDecorators: { player: [{
                type: Input,
                args: [{ required: true }]
            }], actionLabel: [{
                type: Input
            }], selectPlayer: [{
                type: Output
            }] } });

class UxTrendListComponent {
    title = '';
    items = [];
    selectTrend = new EventEmitter();
    playerName(item) {
        return item.player?.fullName ?? item.playerId;
    }
    playerMeta(item) {
        return [item.player?.position, item.player?.team].filter(Boolean).join(' · ');
    }
    countLabel(item) {
        const suffix = item.direction === 'add' ? 'add' : 'drop';
        return `${item.count} ${suffix}${item.count === 1 ? '' : 's'}`;
    }
    icon(item) {
        return item.direction === 'add' ? 'trending_up' : 'trending_down';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxTrendListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxTrendListComponent, isStandalone: true, selector: "ux-trend-list", inputs: { title: "title", items: "items" }, outputs: { selectTrend: "selectTrend" }, ngImport: i0, template: "<section class=\"ux-trend-list\">\n  @if (title) {\n    <h3 class=\"ux-trend-list__title\">{{ title }}</h3>\n  }\n\n  <div class=\"ux-trend-list__items\">\n    @for (item of items; track item.playerId + item.direction) {\n      <button\n        type=\"button\"\n        class=\"ux-trend-list__item ux-trend-list__item--{{ item.direction }}\"\n        (click)=\"selectTrend.emit(item)\"\n      >\n        <mat-icon class=\"ux-trend-list__icon\" aria-hidden=\"true\">{{ icon(item) }}</mat-icon>\n        <span class=\"ux-trend-list__player\">\n          <strong class=\"ux-trend-list__name\">{{ playerName(item) }}</strong>\n          @if (playerMeta(item)) {\n            <span class=\"ux-trend-list__meta\">{{ playerMeta(item) }}</span>\n          }\n        </span>\n        <span class=\"ux-trend-list__count\">{{ countLabel(item) }}</span>\n      </button>\n    }\n  </div>\n</section>\n", styles: [".ux-trend-list{display:grid;gap:var(--ux-space-md, 16px)}.ux-trend-list__title{color:var(--ux-color-text, #182230);font-size:1rem;font-weight:700;margin:0}.ux-trend-list__items{display:grid;gap:var(--ux-space-sm, 8px)}.ux-trend-list__item{align-items:center;background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-md, 12px);color:inherit;cursor:pointer;display:grid;gap:var(--ux-space-sm, 8px);grid-template-columns:auto minmax(0,1fr) auto;justify-content:initial;min-height:4rem;padding:var(--ux-space-sm, 8px) var(--ux-space-md, 16px);text-align:left;width:100%}.ux-trend-list__item:hover,.ux-trend-list__item:focus-visible{border-color:var(--ux-color-primary, #2563eb);outline:none}.ux-trend-list__item--add .ux-trend-list__icon,.ux-trend-list__item--add .ux-trend-list__count{color:var(--ux-color-success, #2e7d5b)}.ux-trend-list__item--drop .ux-trend-list__icon,.ux-trend-list__item--drop .ux-trend-list__count{color:var(--ux-color-danger, #b42318)}.ux-trend-list__icon{font-size:1.25rem;height:1.25rem;width:1.25rem}.ux-trend-list__player{display:grid;gap:var(--ux-space-xs, 4px);min-width:0}.ux-trend-list__name{color:var(--ux-color-text, #182230);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ux-trend-list__meta{color:var(--ux-color-muted-text, #667085);font-size:.8125rem}.ux-trend-list__count{font-size:.8125rem;font-weight:700;white-space:nowrap}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxTrendListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-trend-list', standalone: true, imports: [MatIconModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"ux-trend-list\">\n  @if (title) {\n    <h3 class=\"ux-trend-list__title\">{{ title }}</h3>\n  }\n\n  <div class=\"ux-trend-list__items\">\n    @for (item of items; track item.playerId + item.direction) {\n      <button\n        type=\"button\"\n        class=\"ux-trend-list__item ux-trend-list__item--{{ item.direction }}\"\n        (click)=\"selectTrend.emit(item)\"\n      >\n        <mat-icon class=\"ux-trend-list__icon\" aria-hidden=\"true\">{{ icon(item) }}</mat-icon>\n        <span class=\"ux-trend-list__player\">\n          <strong class=\"ux-trend-list__name\">{{ playerName(item) }}</strong>\n          @if (playerMeta(item)) {\n            <span class=\"ux-trend-list__meta\">{{ playerMeta(item) }}</span>\n          }\n        </span>\n        <span class=\"ux-trend-list__count\">{{ countLabel(item) }}</span>\n      </button>\n    }\n  </div>\n</section>\n", styles: [".ux-trend-list{display:grid;gap:var(--ux-space-md, 16px)}.ux-trend-list__title{color:var(--ux-color-text, #182230);font-size:1rem;font-weight:700;margin:0}.ux-trend-list__items{display:grid;gap:var(--ux-space-sm, 8px)}.ux-trend-list__item{align-items:center;background:var(--ux-color-surface, #ffffff);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-md, 12px);color:inherit;cursor:pointer;display:grid;gap:var(--ux-space-sm, 8px);grid-template-columns:auto minmax(0,1fr) auto;justify-content:initial;min-height:4rem;padding:var(--ux-space-sm, 8px) var(--ux-space-md, 16px);text-align:left;width:100%}.ux-trend-list__item:hover,.ux-trend-list__item:focus-visible{border-color:var(--ux-color-primary, #2563eb);outline:none}.ux-trend-list__item--add .ux-trend-list__icon,.ux-trend-list__item--add .ux-trend-list__count{color:var(--ux-color-success, #2e7d5b)}.ux-trend-list__item--drop .ux-trend-list__icon,.ux-trend-list__item--drop .ux-trend-list__count{color:var(--ux-color-danger, #b42318)}.ux-trend-list__icon{font-size:1.25rem;height:1.25rem;width:1.25rem}.ux-trend-list__player{display:grid;gap:var(--ux-space-xs, 4px);min-width:0}.ux-trend-list__name{color:var(--ux-color-text, #182230);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ux-trend-list__meta{color:var(--ux-color-muted-text, #667085);font-size:.8125rem}.ux-trend-list__count{font-size:.8125rem;font-weight:700;white-space:nowrap}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], items: [{
                type: Input
            }], selectTrend: [{
                type: Output
            }] } });

class UxStatTileComponent {
    label = '';
    value = '';
    delta = null;
    status = 'neutral';
    get hasDelta() {
        return this.delta !== null && this.delta !== undefined && this.delta !== '';
    }
    get deltaIcon() {
        switch (this.status) {
            case 'success':
                return 'trending_up';
            case 'warning':
                return 'priority_high';
            case 'danger':
                return 'trending_down';
            default:
                return 'remove';
        }
    }
    get ariaLabel() {
        const parts = [this.label, String(this.value)];
        if (this.hasDelta) {
            parts.push(String(this.delta));
        }
        return parts.filter(Boolean).join(', ');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxStatTileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxStatTileComponent, isStandalone: true, selector: "ux-stat-tile", inputs: { label: "label", value: "value", delta: "delta", status: "status" }, ngImport: i0, template: "<article class=\"ux-stat-tile ux-stat-tile--{{ status }}\" [attr.aria-label]=\"ariaLabel\" role=\"group\">\n  <div class=\"ux-stat-tile__label\">{{ label }}</div>\n  <div class=\"ux-stat-tile__value\">{{ value }}</div>\n\n  @if (hasDelta) {\n    <div class=\"ux-stat-tile__delta\">\n      <mat-icon class=\"ux-stat-tile__delta-icon\" aria-hidden=\"true\">{{ deltaIcon }}</mat-icon>\n      <span class=\"ux-stat-tile__delta-value\">{{ delta }}</span>\n    </div>\n  }\n</article>\n", styles: [".ux-stat-tile{display:grid;gap:var(--ux-space-xs, 4px);padding:var(--ux-space-md, 16px);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);background:var(--ux-color-surface, #ffffff);color:var(--ux-color-text, #182230)}.ux-stat-tile__label{color:var(--ux-color-muted-text, #667085);font-size:.8125rem;letter-spacing:.02em;text-transform:uppercase}.ux-stat-tile__value{font-size:1.75rem;font-weight:700;line-height:1.1}.ux-stat-tile__delta{align-items:center;display:inline-flex;gap:var(--ux-space-xs, 4px);color:var(--ux-color-muted-text, #667085);font-size:.875rem;min-width:0}.ux-stat-tile__delta-icon{font-size:1rem;height:1rem;width:1rem}.ux-stat-tile--success{border-color:var(--ux-color-success-border, rgba(46, 125, 91, .35))}.ux-stat-tile--warning{border-color:var(--ux-color-warning-border, rgba(181, 71, 8, .35))}.ux-stat-tile--danger{border-color:var(--ux-color-danger-border, rgba(180, 35, 24, .35))}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxStatTileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-stat-tile', standalone: true, imports: [MatIconModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<article class=\"ux-stat-tile ux-stat-tile--{{ status }}\" [attr.aria-label]=\"ariaLabel\" role=\"group\">\n  <div class=\"ux-stat-tile__label\">{{ label }}</div>\n  <div class=\"ux-stat-tile__value\">{{ value }}</div>\n\n  @if (hasDelta) {\n    <div class=\"ux-stat-tile__delta\">\n      <mat-icon class=\"ux-stat-tile__delta-icon\" aria-hidden=\"true\">{{ deltaIcon }}</mat-icon>\n      <span class=\"ux-stat-tile__delta-value\">{{ delta }}</span>\n    </div>\n  }\n</article>\n", styles: [".ux-stat-tile{display:grid;gap:var(--ux-space-xs, 4px);padding:var(--ux-space-md, 16px);border:1px solid var(--ux-color-border, #d9e2ec);border-radius:var(--ux-radius-lg, 16px);background:var(--ux-color-surface, #ffffff);color:var(--ux-color-text, #182230)}.ux-stat-tile__label{color:var(--ux-color-muted-text, #667085);font-size:.8125rem;letter-spacing:.02em;text-transform:uppercase}.ux-stat-tile__value{font-size:1.75rem;font-weight:700;line-height:1.1}.ux-stat-tile__delta{align-items:center;display:inline-flex;gap:var(--ux-space-xs, 4px);color:var(--ux-color-muted-text, #667085);font-size:.875rem;min-width:0}.ux-stat-tile__delta-icon{font-size:1rem;height:1rem;width:1rem}.ux-stat-tile--success{border-color:var(--ux-color-success-border, rgba(46, 125, 91, .35))}.ux-stat-tile--warning{border-color:var(--ux-color-warning-border, rgba(181, 71, 8, .35))}.ux-stat-tile--danger{border-color:var(--ux-color-danger-border, rgba(180, 35, 24, .35))}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], delta: [{
                type: Input
            }], status: [{
                type: Input
            }] } });

function provideUx() {
    return makeEnvironmentProviders([
        { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'outline', subscriptSizing: 'dynamic' } },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { UxAlertComponent, UxButtonDirective, UxDashboardCardComponent, UxDataPanelComponent, UxEmptyStateComponent, UxLoadingStateComponent, UxPlayerCardComponent, UxStatTileComponent, UxTrendListComponent, provideUx };
//# sourceMappingURL=ux-lib-csr-angular-ui.mjs.map
