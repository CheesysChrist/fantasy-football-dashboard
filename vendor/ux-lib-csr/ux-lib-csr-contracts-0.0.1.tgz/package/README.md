# contracts

Shared TypeScript contracts for downstream dashboard apps, package utilities, and backend adapters.

## Fantasy football contracts

The package exports provider-neutral fantasy football data models from `fantasy-data`:

- `NflState`
- `PlayerProfile`
- `PlayerTrend`
- `FantasyDataProvider`

These contracts are intentionally independent of any specific external API so UI components can receive typed inputs without importing Sleeper, ESPN, or paid provider payloads directly.

## Sleeper adapter bridge

For early downstream integration, the package also exports a small Sleeper bridge from `sleeper`:

- `mapSleeperNflState(response)`
- `mapSleeperPlayer(playerId, response)`
- `mapSleeperPlayers(response)`
- `mapSleeperTrend(response, direction, players?)`
- `createSleeperFantasyDataProvider(options?)`

`createSleeperFantasyDataProvider` fetches:

- `GET https://api.sleeper.app/v1/state/nfl`
- `GET https://api.sleeper.app/v1/players/nfl`
- `GET https://api.sleeper.app/v1/players/nfl/trending/<add|drop>?lookback_hours=24&limit=<limit>`

The player dictionary is cached in memory per provider instance so `/players/nfl` is not fetched repeatedly.

```ts
import { createSleeperFantasyDataProvider } from '@ux-lib-csr/contracts';

const provider = createSleeperFantasyDataProvider();
const state = await provider.getNflState();
const addTrends = await provider.getTrendingPlayers('add', 25);
```

Consumer apps should still keep real provider orchestration, backend caching, secrets, and UI loading/error state outside visual components. Components in `@ux-lib-csr/angular-ui` should consume the provider-neutral models as inputs only.

## Building

Run `nx build contracts` to build the library.

## Running unit tests

Run `nx test contracts` to execute the unit tests via [Vitest](https://vitest.dev/).
