import * as i0 from '@angular/core';
import { EventEmitter, EnvironmentProviders } from '@angular/core';

type UxButtonVariant = 'primary' | 'secondary' | 'danger';
type UxButtonSize = 'sm' | 'md' | 'lg';
declare class UxButtonDirective {
    uxVariant: UxButtonVariant;
    uxSize: UxButtonSize;
    uxLoading: boolean;
    get hostClasses(): string;
    get ariaBusy(): 'true' | null;
    get disabled(): '' | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UxButtonDirective, "button[uxButton], a[uxButton]", never, { "uxVariant": { "alias": "uxVariant"; "required": false; }; "uxSize": { "alias": "uxSize"; "required": false; }; "uxLoading": { "alias": "uxLoading"; "required": false; }; }, {}, never, never, true, never>;
}

type UxAlertVariant = 'info' | 'success' | 'warning' | 'danger';
declare class UxAlertComponent {
    title: string;
    variant: UxAlertVariant;
    get role(): 'status' | 'alert';
    static ɵfac: i0.ɵɵFactoryDeclaration<UxAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxAlertComponent, "ux-alert", never, { "title": { "alias": "title"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class UxDashboardCardComponent {
    title: string;
    eyebrow: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxDashboardCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxDashboardCardComponent, "ux-dashboard-card", never, { "title": { "alias": "title"; "required": false; }; "eyebrow": { "alias": "eyebrow"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class UxDataPanelComponent {
    title: string;
    subtitle: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxDataPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxDataPanelComponent, "ux-data-panel", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; }, {}, never, ["[uxDataPanelActions]", "*"], true, never>;
}

type UxEmptyStateVariant = 'card' | 'page';
declare class UxEmptyStateComponent {
    title: string;
    description: string;
    icon: string;
    variant: UxEmptyStateVariant;
    primaryActionLabel: string;
    secondaryActionLabel: string;
    primaryAction: EventEmitter<void>;
    secondaryAction: EventEmitter<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxEmptyStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxEmptyStateComponent, "ux-empty-state", never, { "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "primaryActionLabel": { "alias": "primaryActionLabel"; "required": false; }; "secondaryActionLabel": { "alias": "secondaryActionLabel"; "required": false; }; }, { "primaryAction": "primaryAction"; "secondaryAction": "secondaryAction"; }, never, never, true, never>;
}

type UxLoadingStateMode = 'skeleton' | 'spinner';
declare class UxLoadingStateComponent {
    label: string;
    message: string;
    mode: UxLoadingStateMode;
    rows: number;
    showAvatar: boolean;
    get skeletonRows(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UxLoadingStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxLoadingStateComponent, "ux-loading-state", never, { "label": { "alias": "label"; "required": false; }; "message": { "alias": "message"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "showAvatar": { "alias": "showAvatar"; "required": false; }; }, {}, never, never, true, never>;
}

type UxPlayerTrend = 'add' | 'drop' | 'neutral';
interface UxPlayerCardPlayer {
    fullName: string;
    position: string;
    team?: string;
    status?: string;
    projectedPoints?: number | null;
    trend?: UxPlayerTrend;
}
declare class UxPlayerCardComponent {
    player: UxPlayerCardPlayer;
    actionLabel: string;
    selectPlayer: EventEmitter<UxPlayerCardPlayer>;
    get trend(): UxPlayerTrend;
    get trendLabel(): string;
    get trendIcon(): string;
    get meta(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxPlayerCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxPlayerCardComponent, "ux-player-card", never, { "player": { "alias": "player"; "required": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; }; }, { "selectPlayer": "selectPlayer"; }, never, never, true, never>;
}

type UxTrendDirection = 'add' | 'drop';
interface UxTrendListPlayer {
    fullName: string;
    position: string;
    team?: string;
}
interface UxTrendListItem {
    playerId: string;
    count: number;
    direction: UxTrendDirection;
    player?: UxTrendListPlayer;
}
declare class UxTrendListComponent {
    title: string;
    items: UxTrendListItem[];
    selectTrend: EventEmitter<UxTrendListItem>;
    playerName(item: UxTrendListItem): string;
    playerMeta(item: UxTrendListItem): string;
    countLabel(item: UxTrendListItem): string;
    icon(item: UxTrendListItem): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxTrendListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxTrendListComponent, "ux-trend-list", never, { "title": { "alias": "title"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, { "selectTrend": "selectTrend"; }, never, never, true, never>;
}

type UxStatTileStatus = 'neutral' | 'success' | 'warning' | 'danger';
declare class UxStatTileComponent {
    label: string;
    value: string | number;
    delta: string | number | null;
    status: UxStatTileStatus;
    get hasDelta(): boolean;
    get deltaIcon(): string;
    get ariaLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxStatTileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxStatTileComponent, "ux-stat-tile", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "delta": { "alias": "delta"; "required": false; }; "status": { "alias": "status"; "required": false; }; }, {}, never, never, true, never>;
}

declare function provideUx(): EnvironmentProviders;

export { UxAlertComponent, UxButtonDirective, UxDashboardCardComponent, UxDataPanelComponent, UxEmptyStateComponent, UxLoadingStateComponent, UxPlayerCardComponent, UxStatTileComponent, UxTrendListComponent, provideUx };
export type { UxAlertVariant, UxButtonSize, UxButtonVariant, UxEmptyStateVariant, UxLoadingStateMode, UxPlayerCardPlayer, UxPlayerTrend, UxStatTileStatus, UxTrendDirection, UxTrendListItem, UxTrendListPlayer };
