import * as i0 from '@angular/core';
import { EnvironmentProviders } from '@angular/core';

type UxButtonVariant = 'primary' | 'secondary' | 'danger';
type UxButtonSize = 'sm' | 'md' | 'lg';
declare class UxButtonDirective {
    uxVariant: UxButtonVariant;
    uxSize: UxButtonSize;
    uxLoading: boolean;
    get hostClasses(): string;
    get ariaBusy(): 'true' | null;
    get disabled(): '' | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UxButtonDirective, "button[uxButton], a[uxButton]", never, { "uxVariant": { "alias": "uxVariant"; "required": false; }; "uxSize": { "alias": "uxSize"; "required": false; }; "uxLoading": { "alias": "uxLoading"; "required": false; }; }, {}, never, never, true, never>;
}

type UxAlertVariant = 'info' | 'success' | 'warning' | 'danger';
declare class UxAlertComponent {
    title: string;
    variant: UxAlertVariant;
    get role(): 'status' | 'alert';
    static ɵfac: i0.ɵɵFactoryDeclaration<UxAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxAlertComponent, "ux-alert", never, { "title": { "alias": "title"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class UxDashboardCardComponent {
    title: string;
    eyebrow: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UxDashboardCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UxDashboardCardComponent, "ux-dashboard-card", never, { "title": { "alias": "title"; "required": false; }; "eyebrow": { "alias": "eyebrow"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare function provideUx(): EnvironmentProviders;

export { UxAlertComponent, UxButtonDirective, UxDashboardCardComponent, provideUx };
export type { UxAlertVariant, UxButtonSize, UxButtonVariant };
