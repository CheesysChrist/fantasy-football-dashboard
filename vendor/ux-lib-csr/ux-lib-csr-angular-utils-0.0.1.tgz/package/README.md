# angular-utils

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build angular-utils` to build the library.

## Running unit tests

Run `nx test angular-utils` to execute the unit tests via [Vitest](https://vitest.dev/).
