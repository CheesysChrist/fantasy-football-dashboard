import * as i0 from '@angular/core';
import { HostBinding, Input, Directive, ChangeDetectionStrategy, Component, makeEnvironmentProviders } from '@angular/core';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';

class UxButtonDirective {
    uxVariant = 'primary';
    uxSize = 'md';
    uxLoading = false;
    get hostClasses() {
        return `ux-button ux-button--${this.uxVariant} ux-button--${this.uxSize}${this.uxLoading ? ' ux-button--loading' : ''}`;
    }
    get ariaBusy() {
        return this.uxLoading ? 'true' : null;
    }
    get disabled() {
        return this.uxLoading ? '' : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.14", type: UxButtonDirective, isStandalone: true, selector: "button[uxButton], a[uxButton]", inputs: { uxVariant: "uxVariant", uxSize: "uxSize", uxLoading: "uxLoading" }, host: { properties: { "class": "this.hostClasses", "attr.aria-busy": "this.ariaBusy", "attr.disabled": "this.disabled" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[uxButton], a[uxButton]',
                    standalone: true,
                }]
        }], propDecorators: { uxVariant: [{
                type: Input
            }], uxSize: [{
                type: Input
            }], uxLoading: [{
                type: Input
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], ariaBusy: [{
                type: HostBinding,
                args: ['attr.aria-busy']
            }], disabled: [{
                type: HostBinding,
                args: ['attr.disabled']
            }] } });

class UxAlertComponent {
    title = 'Notice';
    variant = 'info';
    get role() {
        return this.variant === 'danger' || this.variant === 'warning' ? 'alert' : 'status';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.14", type: UxAlertComponent, isStandalone: true, selector: "ux-alert", inputs: { title: "title", variant: "variant" }, ngImport: i0, template: "<section class=\"ux-alert ux-alert--{{ variant }}\" [attr.role]=\"role\">\n  <strong class=\"ux-alert__title\">{{ title }}</strong>\n  <p class=\"ux-alert__message\"><ng-content /></p>\n</section>\n", styles: [".ux-alert{border:1px solid #d9e2ec;border-radius:10px;padding:16px;background:#fff}.ux-alert__title{display:block;margin-bottom:4px}.ux-alert__message{margin:0;color:#667085}.ux-alert--success{border-color:#2e7d5b59}.ux-alert--warning{border-color:#b5470859}.ux-alert--danger{border-color:#b4231859}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-alert', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"ux-alert ux-alert--{{ variant }}\" [attr.role]=\"role\">\n  <strong class=\"ux-alert__title\">{{ title }}</strong>\n  <p class=\"ux-alert__message\"><ng-content /></p>\n</section>\n", styles: [".ux-alert{border:1px solid #d9e2ec;border-radius:10px;padding:16px;background:#fff}.ux-alert__title{display:block;margin-bottom:4px}.ux-alert__message{margin:0;color:#667085}.ux-alert--success{border-color:#2e7d5b59}.ux-alert--warning{border-color:#b5470859}.ux-alert--danger{border-color:#b4231859}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], variant: [{
                type: Input
            }] } });

class UxDashboardCardComponent {
    title = '';
    eyebrow = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxDashboardCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.14", type: UxDashboardCardComponent, isStandalone: true, selector: "ux-dashboard-card", inputs: { title: "title", eyebrow: "eyebrow" }, ngImport: i0, template: "<article class=\"ux-dashboard-card\">\n  <header class=\"ux-dashboard-card__header\">\n    @if (eyebrow) {\n      <span class=\"ux-dashboard-card__eyebrow\">{{ eyebrow }}</span>\n    }\n    <h2>{{ title }}</h2>\n  </header>\n  <ng-content />\n</article>\n", styles: [".ux-dashboard-card{background:#fff;border:1px solid #d9e2ec;border-radius:16px;padding:24px;box-shadow:0 12px 30px #10182814}.ux-dashboard-card__header{margin-bottom:16px}.ux-dashboard-card__eyebrow{color:#667085;font-size:.75rem;text-transform:uppercase;letter-spacing:.08em}.ux-dashboard-card h2{margin:4px 0 0;font-size:1.1rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.14", ngImport: i0, type: UxDashboardCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ux-dashboard-card', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<article class=\"ux-dashboard-card\">\n  <header class=\"ux-dashboard-card__header\">\n    @if (eyebrow) {\n      <span class=\"ux-dashboard-card__eyebrow\">{{ eyebrow }}</span>\n    }\n    <h2>{{ title }}</h2>\n  </header>\n  <ng-content />\n</article>\n", styles: [".ux-dashboard-card{background:#fff;border:1px solid #d9e2ec;border-radius:16px;padding:24px;box-shadow:0 12px 30px #10182814}.ux-dashboard-card__header{margin-bottom:16px}.ux-dashboard-card__eyebrow{color:#667085;font-size:.75rem;text-transform:uppercase;letter-spacing:.08em}.ux-dashboard-card h2{margin:4px 0 0;font-size:1.1rem}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], eyebrow: [{
                type: Input
            }] } });

function provideUx() {
    return makeEnvironmentProviders([
        { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'outline', subscriptSizing: 'dynamic' } },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { UxAlertComponent, UxButtonDirective, UxDashboardCardComponent, provideUx };
//# sourceMappingURL=ux-lib-csr-angular-ui.mjs.map
